import mongoose, { Schema } from "mongoose";
import mongooseAggreagatePginate from "mongoose-aggregate-paginate-v2";
const videoSchema = new Schema({
    videofile: {
        type: String, //cloudinary url
        required: true,
    },
    thumbnail: {
        type: String, //cloudinary url
        required: true
    },
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    duration: {
        type: Number, //cloudinary url updates
        required: true
    },
    views: {
        types: Number,
        default: 0
    },
    isPublished:{
        type:Boolean,
        default:true
    },
    owner:{
        type:Schema.Types.ObjectId,
        ref:"User"
    }
},
    { timestamps: true }
)
videoSchema.plugin(mongooseAggreagatePginate)
export const Video = mongoose.model('Video', videoSchema)