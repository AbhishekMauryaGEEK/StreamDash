import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const ProtectedRoute = ({ children }) => {
    const { user, loading } = useAuth();

    if (loading) return <div className="h-screen flex items-center justify-center bg-background text-white">Verifying...</div>;

    if (!user) {
        // FIX: Redirect to /auth, not /login
        return <Navigate to="/auth" replace />;
    }

    return children;
};

export default ProtectedRoute;