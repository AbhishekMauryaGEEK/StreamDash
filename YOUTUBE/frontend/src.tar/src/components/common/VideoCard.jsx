import React, { useState, useRef, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { MoreVertical, CheckCircle, Edit, Trash2, Eye, EyeOff, Share2, X, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../../utils/axios';

export default function VideoCard({ video, currentUser, onVideoUpdate }) {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);
    const [isCopied, setIsCopied] = useState(false);

    const menuRef = useRef(null);

    // --- CRITICAL OWNERSHIP CHECK ---
    const videoOwnerId = video.ownerDetails?._id || video.owner;
    const isOwner = currentUser?._id && videoOwnerId && String(currentUser._id) === String(videoOwnerId);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) setIsMenuOpen(false);
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    if (!video) return null;

    const shareVideo = async (e) => {
        e.preventDefault();
        try {
            await navigator.clipboard.writeText(`${window.location.origin}/watch/${video._id}`);
            setIsCopied(true);
            setTimeout(() => { setIsCopied(false); setIsMenuOpen(false); }, 2000);
        } catch (err) { console.error(err); }
    };

    const handleDelete = async () => {
        setIsUpdating(true);
        try {
            await api.delete(`/videos/${video._id}`);
            if (onVideoUpdate) onVideoUpdate();
        } finally { setIsUpdating(false); setShowDeleteModal(false); }
    };

    const handleToggleStatus = async () => {
        try {
            await api.patch(`/videos/toggle/publish/${video._id}`);
            if (onVideoUpdate) onVideoUpdate();
            setIsMenuOpen(false);
        } catch (err) { console.error(err); }
    };

    return (
        <div className="flex flex-col gap-3 group relative">
            <Link to={`/watch/${video._id}`} className="relative aspect-video rounded-2xl overflow-hidden bg-zinc-900 border border-white/5 shadow-lg">
                <img src={video.thumbnail} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="" />
                {!video.isPublished && (
                    <div className="absolute top-2 left-2 bg-red-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">Private</div>
                )}
            </Link>

            <div className="flex gap-3 px-1">
                <Link to={`/c/${video.ownerDetails?.username}`} className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 border border-white/10">
                    <img src={video.ownerDetails?.avatar} className="w-full h-full object-cover" alt="" />
                </Link>

                <div className="flex flex-col flex-1 overflow-hidden">
                    <Link to={`/watch/${video._id}`} className="font-bold text-white text-sm line-clamp-2">{video.title}</Link>
                    <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                        {video.ownerDetails?.username} <CheckCircle size={10} />
                    </p>
                    <p className="text-[11px] text-gray-500">{video.views} views • {formatDistanceToNow(new Date(video.createdAt))} ago</p>
                </div>

                <div ref={menuRef} className="relative">
                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-1 text-gray-400 hover:text-white rounded-full hover:bg-white/10"><MoreVertical size={18} /></button>
                    {isMenuOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl py-2 z-50">
                            <button onClick={shareVideo} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                                <Share2 size={16} className={isCopied ? "text-green-500" : ""} /> {isCopied ? "Copied!" : "Share"}
                            </button>
                            {isOwner && (
                                <>
                                    <div className="h-px bg-white/5 my-1" />
                                    <button onClick={handleToggleStatus} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-300 hover:bg-white/10">
                                        {video.isPublished ? <EyeOff size={16} /> : <Eye size={16} />} {video.isPublished ? "Make Private" : "Make Public"}
                                    </button>
                                    <button onClick={() => { setShowDeleteModal(true); setIsMenuOpen(false); }} className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-red-500/10">
                                        <Trash2 size={16} /> Delete
                                    </button>
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {showDeleteModal && (
                <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
                    <div className="bg-[#121212] border border-white/10 p-6 rounded-2xl w-full max-w-md">
                        <h2 className="text-xl font-bold text-white mb-4">Delete Video?</h2>
                        <div className="flex justify-end gap-3">
                            <button onClick={() => setShowDeleteModal(false)} className="px-4 py-2 text-white hover:bg-white/10 rounded-lg">Cancel</button>
                            <button onClick={handleDelete} className="bg-red-600 px-4 py-2 rounded-lg text-white font-bold">Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}