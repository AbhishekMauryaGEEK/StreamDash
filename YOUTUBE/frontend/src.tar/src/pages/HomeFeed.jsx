import React, { useState, useEffect } from 'react';
import api from '../utils/axios';
import VideoCard from '../components/common/VideoCard';
import { useAuth } from '../context/AuthContext';

const HomeFeed = () => {
    const { user } = useAuth(); 
    const [videos, setVideos] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchVideos = async () => {
        try {
            const res = await api.get('/videos');
            setVideos(res.data.data.docs || res.data.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchVideos(); }, []);

    if (loading) return <div className="h-96 flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div></div>;

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {videos.map((video) => (
                <VideoCard 
                    key={video._id} 
                    video={video} 
                    currentUser={user} 
                    onVideoUpdate={fetchVideos}
                />
            ))}
        </div>
    );
};

export default HomeFeed;