import mongoose, { Schema } from "mongoose";

const subscriptionSchema = new Schema({
    subscriber: {
        type: Schema.Types.ObjectId, // User who is following
        ref: "User"
    },
    channel: {
        type: Schema.Types.ObjectId, // User being followed
        ref: "User"
    }
}, { timestamps: true });

// Mongoose will automatically create/use the "subscriptions" collection
export const Subscription = mongoose.model("Subscription", subscriptionSchema);