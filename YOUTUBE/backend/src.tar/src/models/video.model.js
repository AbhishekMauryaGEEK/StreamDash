import mongoose, { Schema } from "mongoose";
import mongooseAggreagatePginate from "mongoose-aggregate-paginate-v2";
const videoSchema = new Schema(
    {
        videoFile: { type: String, required: true },
        thumbnail: { type: String, required: true },
        title: { type: String, required: true },
        description: { type: String, required: true },
        duration: { type: Number, required: true },
        views: {
            type: Number,
            default: 0  // Ensure no quotes, no extra brackets
        },
        isPublished: {
            type: Boolean,
            default: true
        },
        owner: {
            type: String,
            ref: "User",// Since you are using UUID strings
            required: true
        }
    },
    { timestamps: true }
);
videoSchema.plugin(mongooseAggreagatePginate)
export const Video = mongoose.model('Video', videoSchema)