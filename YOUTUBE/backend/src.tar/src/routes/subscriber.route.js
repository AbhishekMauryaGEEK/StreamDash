import { Router } from "express";
import { verifyJWT } from "../middlewares/auth.middleware.js";
import { 
    getSubscribedChannels, 
    getUserChannelSubscribers, 
    toggleSubscription 
} from "../controllers/subscription.controller.js";

const router = Router();
router.use(verifyJWT);

// Static route first to prevent it being caught by :channelId
router.route("/u/subscribed").get(getSubscribedChannels);

router.route("/c/:channelId")
    .post(toggleSubscription)
    .get(getUserChannelSubscribers);

export default router;