import { Router } from 'express';
import {
    getLikedVideos,
    toggleCommentLike,
    toggletweetlike,
    togglevideolike,
} from "../controllers/like.controller.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const likeRouter =Router();
likeRouter.use(verifyJWT); 
likeRouter.route("/toggle/v/:videoId").post(togglevideolike);
likeRouter.route("/toggle/c/:commentId").post(toggleCommentLike);
likeRouter.route("/toggle/t/:tweetId").post(toggletweetlike);
likeRouter.route("/videos").get(getLikedVideos);
export default likeRouter;