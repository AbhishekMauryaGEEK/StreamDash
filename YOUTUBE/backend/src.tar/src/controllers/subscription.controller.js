import mongoose, { isValidObjectId } from "mongoose";
import { Subscription } from "../models/subscription.model.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { asynchandler } from "../utils/asyncHandler.js";

const toggleSubscription = asynchandler(async (req, res) => {
    const { channelId } = req.params;
    if (!isValidObjectId(channelId)) throw new ApiError(400, "Invalid Channel ID");

    const credentials = { subscriber: req.user?._id, channel: channelId };
    const existedSubscription = await Subscription.findOne(credentials);

    if (existedSubscription) {
        await Subscription.findByIdAndDelete(existedSubscription._id);
        return res.status(200).json(new ApiResponse(200, { subscribed: false }, "Unsubscribed"));
    }

    await Subscription.create(credentials);
    return res.status(200).json(new ApiResponse(200, { subscribed: true }, "Subscribed"));
});

const getSubscribedChannels = asynchandler(async (req, res) => {
    const subscriberId = req.user?._id;

    const subscribedChannels = await Subscription.aggregate([
        { $match: { subscriber: new mongoose.Types.ObjectId(subscriberId) } },
        {
            $lookup: {
                from: "users",
                localField: "channel",
                foreignField: "_id",
                as: "subscribedChannel",
                pipeline: [{ $project: { username: 1, fullName: 1, avatar: 1 } }]
            }
        },
        { $unwind: "$subscribedChannel" },
        { $project: { _id: 0, subscribedChannel: 1 } }
    ]);

    return res.status(200).json(new ApiResponse(200, subscribedChannels, "Channels fetched"));
});

const getUserChannelSubscribers = asynchandler(async (req, res) => {
    const { channelId } = req.params;
    if (!isValidObjectId(channelId)) throw new ApiError(400, "Invalid Channel ID");

    const subscribers = await Subscription.aggregate([
        { $match: { channel: new mongoose.Types.ObjectId(channelId) } },
        {
            $lookup: {
                from: "users",
                localField: "subscriber",
                foreignField: "_id",
                as: "subscriber",
                pipeline: [{ $project: { username: 1, fullName: 1, avatar: 1 } }]
            }
        },
        { $unwind: "$subscriber" },
        { $project: { _id: 0, subscriber: 1 } }
    ]);

    return res.status(200).json(new ApiResponse(200, subscribers, "Subscribers fetched"));
});

export { toggleSubscription, getSubscribedChannels, getUserChannelSubscribers };